

1. The installed VIB Package can be list using command 
	"esxcli software vib list "
 
2. The VIB Package can be installed using the command, please pass the all path for the vib package
	example of the path of the vib: /vmfs/volume/datastore1
	"esxcli software vib install -v /vmfs/volume/datastore1/vmware-esx-perccli.vib --no-sig-check"

3.The VIB Package can be removed using the command
	"esxcli software vib remove -n=vmware-esx-perccli.vib --force"

4. To run the perccli, go to "cd /opt/lsi/perccli"
	"./perccli show"


Notes:
Please make sure the acceptance level is "PartnerSupported", it can be list using command
	"esxcli software acceptance get"

If not, please change to "PartnerSupported" using commnad
	"esxcli software acceptance set --level=PartnerSupported