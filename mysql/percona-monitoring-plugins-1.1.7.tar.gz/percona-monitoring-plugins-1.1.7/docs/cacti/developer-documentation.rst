.. _cacti_developer_documentation:

Cacti Templates Developer Documentation
=======================================

This documentation is for users who wish to extend the Cacti templates to create
new graphs, collect new types of data, and so on.

.. toctree::

   adding-graphs
   cacti-hashes
   creating-graphs
   helper-tools
